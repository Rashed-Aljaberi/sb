import streamlit as st
import boto3
import json
from PIL import Image
import io
import base64
import logging
import time
import requests
from streamlit_elements import elements, mui, html

def get_function_names():
    cfn_client = boto3.client('cloudformation')
    stack_name = "SkincareCdkStack"  # Replace with your actual stack name

    response = cfn_client.describe_stacks(StackName=stack_name)
    outputs = response['Stacks'][0]['Outputs']

    function_names = {}
    for output in outputs:
        if output['OutputKey'] == 'AnalyzeFaceFunctionName':
            function_names['analyze_face'] = output['OutputValue']
        elif output['OutputKey'] == 'GetRecommendationFunctionName':
            function_names['get_recommendation'] = output['OutputValue']

    return function_names

function_names = get_function_names()
analyze_face_function_name = function_names['analyze_face']
get_recommendation_function_name = function_names['get_recommendation']

# Custom CSS
st.markdown(
    """
    <style>
        body {
            background-color: #f4e6bf; /* Accent color for background */
            margin: 0;
            padding: 0;
        }

        .st-emotion-cache-bm2z3a {
            background-color: #fbfaf2;
        }

        /* Style for buttons in stButton and form submit button */
        .stButton button, .stButton button[form="update_analysis"] {
            background-color: #ffffff;
            color: #333333;
            border: 2px solid #f4e6bf;
            border-radius: 5px;
            padding: 10px;
            width: 100%;
            box-sizing: border-box;
            transition: background-color 0.3s ease, color 0.3s ease, border-color 0.3s ease;
            outline: none;
            cursor: pointer;
        }

        /* Hover effect */
        .stButton button:hover, .stButton button[form="update_analysis"]:hover {
            background-color: #f4e6bf;
            color: #ffffff;
            border-color: #f4e6bf;
        }

        /* Focus and active states */
        .stButton button:focus,
        .stButton button:active,
        .stButton button[form="update_analysis"]:focus,
        .stButton button[form="update_analysis"]:active {
            background-color: #ffffff;
            color: #f4e6bf;
            border-color: #f4e6bf;
            outline: none;
        }

        h1 {
            font-family: 'Arial', sans-serif; /* Clean, modern font */
            font-size: 2.5rem; /* Prominent but not overwhelming */
            color: #333333; /* Dark text for contrast */
            text-align: center; /* Center-align the title */
            line-height: 1.4; /* Better readability */
            padding: 20px; /* Add padding around the title */
            margin: 20px 0; /* Add space above and below */
            text-transform: uppercase; /* Optional: make the text uppercase */
            letter-spacing: 1px; /* Optional: add slight spacing between letters */
        }
        
       
       /* bottom padding for title on selection page */
        .st-emotion-cache-1104ytp h1 {
            padding: 1.25rem 0px 2rem;
        }

        /* upload page styling */

        .st-emotion-cache-1gulkj5{
            background-color: #f4e6bf;
            color: dark gray;
            font-weight: 400;
        }

        .st-emotion-cache-133trn5 {
            color: white;
        }

        .result-item {
            background-color: #f4e6bf9c;
            border-radius: 5px;
            padding: 10px;
            margin: 5px 0;
            font-weight: bold;
        }
        .result-label {
            color: #707070;
        }
        .result-value {
            color: #8f8f8f;
        }

        /* margin for titles in results */
        .st-emotion-cache-1104ytp p {
            margin: 20px 0px 0px 0px;
            font-weight: 700 !important;
        }

        @media (max-width: 768px) {
            body {
                text-align: center; /* Center text and content */
            }

            .scrollableTextbox {
                margin: 10px auto; /* Center the textbox */
                width: 100%; /* Full width on mobile */
            }

            .stButton {
                margin: 10px auto; /* Center button container */
            }

            .stButton button {
                width: 100%; /* Full width buttons */
            }

            h1 {
                font-size: 2rem; /* Smaller title for mobile */
                padding: 10px; /* Adjust padding for smaller screens */
            }
        }
    </style>
    """,
    unsafe_allow_html=True,
)

# Set up logging
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# Initialize AWS clients
lambda_client = boto3.client("lambda")


def analyze_face(image_bytes):
    logger.info("Encoding image to base64")
    encoded_image = base64.b64encode(image_bytes).decode("utf-8")
    logger.info("Invoking analyzeFace Lambda function")
    try:
        response = lambda_client.invoke(
            FunctionName=analyze_face_function_name,
            InvocationType="RequestResponse",
            Payload=json.dumps({"image": encoded_image}),
        )
        logger.info("Received response from analyzeFace Lambda")
        result = json.loads(response["Payload"].read())
        logger.info(f"analyzeFace result: {result}")
        if result["statusCode"] == 200:
            return json.loads(result["body"])
        else:
            logger.error(f"Error in analyzeFace: {result.get('body', 'Unknown error')}")
            return None
    except Exception as e:
        logger.error(f"Exception in analyze_face: {str(e)}")
        return None


def get_recommendations(age, skin_type, gender, skin_health, skin_concerns, additional_info):
    logger.info(
        f"Getting recommendations for age: {age}, skin_type: {skin_type}, gender: {gender}, "
        f"skin_health: {skin_health}, skin_concerns: {skin_concerns}"
        f"additional_info: {additional_info}"
    )
    try:
        response = lambda_client.invoke(
            FunctionName=get_recommendation_function_name,
            InvocationType="RequestResponse",
            Payload=json.dumps(
                {
                    "age": age,
                    "type": skin_type,
                    "gender": gender,
                    "skin_health": skin_health,
                    "skin_concerns": skin_concerns,
                    "additional_info": additional_info
                }
            ),
        )
        result = json.loads(response["Payload"].read())
        logger.info(f"getRecommendations result: {result}")
        if result["statusCode"] == 200:
            body = json.loads(result["body"])
            return {"success": True, "data": body["agent_response"]}
        else:
            error_body = json.loads(result.get("body", "{}"))
            if error_body.get("error") == "throttlingException":
                return {"success": False, "error": "throttling"}
            logger.error(
                f"Error in getRecommendations: {result.get('body', 'Unknown error')}"
            )
            return {"success": False, "error": "general"}
    except Exception as e:
        logger.error(f"Exception in get_recommendations: {str(e)}")
        return {"success": False, "error": "general"}

def selection_page():
    st.title("Welcome to Your Beauty Routine Generator")

    # Initialize session state
    if 'page' not in st.session_state:
        st.session_state.page = 'selection'
    if 'category' not in st.session_state:
        st.session_state.category = None

    # Create a container for buttons
    button_container = st.container()

    with button_container:
        # Buttons for category selection
        if st.button("Hair Care", key="hair_care"):
            st.session_state.page = "upload"
            st.session_state.category = "Hair Care"
            st.rerun()
        if st.button("Skin Care", key="skin_care"):
            st.session_state.page = "upload"
            st.session_state.category = "Skin Care"
            st.rerun()
        if st.button("Makeup", key="makeup"):
            st.session_state.page = "upload"
            st.session_state.category = "Makeup"
            st.rerun()

def upload_page():
    if 'face_analysis' not in st.session_state:
        st.session_state.face_analysis = None
    if 'button_clicked' not in st.session_state:
        st.session_state.button_clicked = False

    st.title("Upload Your Photo")
    st.write("Please upload a clear, front-facing photo of your face.")
    st.title("Upload or Capture a Photo")
    
    # Option to upload a file
    uploaded_file = st.file_uploader("Upload a photo", type=["jpg", "jpeg", "png"])
    
    # Option to capture from camera
    camera_image = st.camera_input("Or take a picture")
    
    if uploaded_file is not None:
        image = Image.open(uploaded_file)
    elif camera_image is not None:
        image = Image.open(camera_image)
    else:
        st.write("Please upload an image or take a picture")
        return

    if image:
        bg_color = (0, 0, 0)  # Black
        border_width = 10  
        new_image_size = (image.width + 2 * border_width, image.height + 2 * border_width)
        new_image = Image.new("RGB", new_image_size, bg_color)
        new_image.paste(image, (border_width, border_width), image if image.mode == 'RGBA' else None)
        
        # Display the image
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.image(new_image, caption="Uploaded Image", use_container_width=True)
            if st.button("Analyze", key="analyze_button"):
                st.session_state.button_clicked = True
                st.rerun()

        if st.session_state.button_clicked:
            with st.spinner("Analyzing your face..."):
                img_byte_arr = io.BytesIO()
                image.save(img_byte_arr, format='PNG')
                logger.info(f"Image size before processing : {len(img_byte_arr.getvalue())} bytes ")

                if len(img_byte_arr.getvalue()) > 6000000:  # 6MB limit
                    logger.info("Image exceeds 6MB limit, resizing...")
                    image = Image.open(io.BytesIO(img_byte_arr.getvalue()))
                    target_size = 2000000  # 2MB limit
                    scale_factor = 0.4
                    while True:
                        img_byte_arr = io.BytesIO()
                        width, height = image.size
                        new_width = int(width * scale_factor)
                        new_height = int(height * scale_factor)
                        resized_image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
                        resized_image.save(img_byte_arr, format="PNG")
                        img_byte_arr.seek(0)
                        current_size = len(img_byte_arr.getvalue())
                        logger.info(f"Current image size: {current_size} bytes with scale factor {scale_factor}")
                        if current_size <= target_size:
                            image = resized_image
                            break
                        scale_factor *= 0.9
                        if scale_factor <= 0.1:
                            break

                logger.info(f"Image size after processing: {len(img_byte_arr.getvalue())} bytes")
                img_byte_arr.seek(0)

                st.session_state.face_analysis = analyze_face(img_byte_arr.getvalue())
                
                if st.session_state.face_analysis is not None:
                    try:
                        results = json.loads(st.session_state.face_analysis["output"]["message"]["content"][0]["text"])
                        logger.info(f"Face analysis results: {results}")
                        st.session_state.results = results
                        
                        # Reset states and navigate to results
                        st.session_state.button_clicked = False
                        st.session_state.page = "results"
                        st.rerun()
                    except (json.JSONDecodeError, KeyError, IndexError) as e:
                        st.error(f"Error processing face analysis results: {str(e)}")
                        logger.error(f"Face analysis result processing error: {str(e)}")
                else:
                    st.error("Face analysis failed. Please try again.")
    else:
        st.write("No image uploaded yet.")

def results_page():
    st.title("Analysis Results")
    if "results" in st.session_state:
        results = st.session_state.results

        st.markdown("Please confirm that the following analysis is accurate. You can change any of the details below.")

        skin_type_options = ["Normal", "Dry", "Oily", "Combination", "Combination to oily"]
        skin_health_options = ["Excellent", "Good", "Fair", "Poor", "Moderate"]
        age_range_options = ["18-24", "25-34", "35-44", "45-54", "55+"]
        gender_options = ["Female", "Male", "Other"]
        skin_concerns_options = [
            "Acne", "Wrinkles", "Pigmentation", "Sensitivity", "Dryness", "Redness", "Uneven Texture"
        ]

        with st.form("update_analysis"):
            skin_type = results.get("skinType", skin_type_options[0])
            if skin_type not in skin_type_options:
                skin_type_options.append(skin_type)
            new_skin_type = st.selectbox("Skin Type", skin_type_options, index=skin_type_options.index(skin_type))

            skin_health = results.get("skinHealth", skin_health_options[0])
            if skin_health not in skin_health_options:
                skin_health_options.append(skin_health)
            new_skin_health = st.selectbox("Skin Health", skin_health_options, index=skin_health_options.index(skin_health))

            gender = results.get("gender", gender_options[0])
            if gender not in gender_options:
                gender_options.append(gender)
            new_gender = st.selectbox("Gender", gender_options, index=gender_options.index(gender))

            age = results.get("estimatedAge", age_range_options[0])
            if age not in age_range_options:
                age_range_options.append(age)
            new_age = st.selectbox("Age Range", age_range_options, index=age_range_options.index(age))

            # In the results_page() function:
            valid_concerns = results.get("skinConcerns", [])
            for concern in valid_concerns:
                if concern not in skin_concerns_options:
                    skin_concerns_options.append(concern)

            new_concerns = st.multiselect(
                "Skin Concerns",
                skin_concerns_options,
                default=valid_concerns
            )
            additional_info = st.text_area("Additional Information (e.g., allergies)")

            if st.form_submit_button("Confirm Analysis"):
                results["skinType"] = new_skin_type
                results["skinHealth"] = new_skin_health
                results["gender"] = new_gender
                results["estimatedAge"] = new_age
                results["skinConcerns"] = new_concerns

                while True:
                    recommendations = get_recommendations(
                        results["estimatedAge"],
                        results["skinType"].lower(),
                        results["gender"].lower(),
                        results["skinHealth"],
                        results["skinConcerns"],
                        additional_info
                    )
                    if recommendations["success"]:
                        st.write("Your Personalized Skincare Routine:")
                        routine_text = recommendations["data"]
                        st.markdown(routine_text)

                        product_lines = routine_text.split("\n")
                        products = [
                            line.split(":**", 1)[1].strip()
                            for line in product_lines
                            if "**Product Name:**" in line
                        ]

                        placeholder_image_url = "https://8c3412d76225d04d7baa-be98b6ea17920953fb931282eff9a681.images.lovelyskin.com/fk4rdxrf_202405161712120966.jpg"

                        for index, product in enumerate(products):
                            col1, col2, col3 = st.columns([3, 1, 1])
                            with col1:
                                st.markdown(f"**{product}**")
                            with col2:
                                try:
                                    st.image(placeholder_image_url, use_container_width=True)
                                except Exception as e:
                                    st.warning("Unable to load image")
                            with col3:
                                with elements(f"shop_button_{index}"):  # Use a unique key for each button
                                    mui.Button(
                                    "Add to Cart",
                                    variant="contained",
                                    startIcon=mui.Icon("add_shopping_cart"),
                                    onClick=lambda p=product: open_shop_link(p)
                                    )
                        break
                    
                    elif recommendations["error"] == "throttling":
                        st.error(
                            "The service is currently experiencing high demand. Please try again."
                        )
                        time.sleep(20)
                    else:
                        st.error(
                            "Unable to generate recommendations. Please try again."
                        )
                        break
    else:
        st.error("Face analysis data is not available.")
    # Add Retry button
    if st.button("Start Over"):
        st.session_state.page = "selection"
        st.session_state.results = None
        st.session_state.face_analysis = None
        st.rerun()
        
def open_shop_link(product):
    # Implement the logic to open a shop link for the product
    st.write(f"Opening shop link for {product}")
        
# Main app logic
if "page" not in st.session_state:
    st.session_state.page = "selection"

if st.session_state.page == "selection":
    selection_page()
elif st.session_state.page == "upload":
    upload_page()
elif st.session_state.page == "results":
    results_page()
logger.info("Streamlit app is ready")
