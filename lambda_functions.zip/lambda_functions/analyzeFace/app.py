import json
import base64
import asyncio
import aioboto3


async def analyze_with_rekognition(image_bytes):
    async with aioboto3.Session().client("rekognition") as rekognition_client:
        response = await rekognition_client.detect_faces(
            Image={"Bytes": image_bytes}, Attributes=["ALL"]
        )
        return response


async def analyze_with_nova(image_bytes):
    async with aioboto3.Session().client("bedrock-runtime") as bedrock_client:
        # Define system prompts for skin and facial feature analysis
        system_prompts = [
            {
                "text": (
                    "You are a skincare and facial analysis expert. Analyze the provided image for skin type, "
                    "health, visible concerns, gender, and estimated age. Return the results in JSON format, no markdown, no special characters, pure json, with the following structure: "
                    "{\n"
                    '  "skinType": "",\n'
                    '  "skinHealth": "",\n'
                    '  "skinConcerns": [],\n'
                    '  "gender": "",\n'
                    '  "estimatedAge": ""\n'
                    "}"
                )
            }
        ]

        # Prepare the Base64 encoded image
        base64_string = base64.b64encode(image_bytes).decode("utf-8")

        # Define user messages including both the image and a text prompt
        message_list = [
            {
                "role": "user",
                "content": [
                    {
                        "image": {
                            "format": "png",  # Adjust this based on your image format
                            "source": {"bytes": base64_string},
                        }
                    },
                    {
                        "text": "Analyze this image for skin type, overall skin health, and visible concerns."
                    },
                ],
            }
        ]

        # Configure inference parameters
        inf_params = {
            "max_new_tokens": 300,
            "top_p": 0.9,
            "top_k": 50,
            "temperature": 0.5,
        }

        # Construct the request body
        request_body = {
            "schemaVersion": "messages-v1",
            "messages": message_list,
            "system": system_prompts,
            "inferenceConfig": inf_params,
        }

        print("Calling the Nova model...")

        # Invoke the Nova Pro model
        response = await bedrock_client.invoke_model(
            modelId="us.amazon.nova-pro-v1:0",  # Ensure this is correct for Nova Pro
            body=json.dumps(request_body),
        )

        response_body = json.loads(
            await response["body"].read()
        )  # Await reading the body
        return response_body  # Adjust based on how you want to handle the response


async def analyze_face(image_bytes):
    rekognition_task = asyncio.create_task(analyze_with_rekognition(image_bytes))
    nova_task = asyncio.create_task(analyze_with_nova(image_bytes))

    results = await asyncio.gather(rekognition_task, nova_task)

    rekognition_result, nova_result = results

    if rekognition_result:
        return {**rekognition_result, **nova_result}
    else:
        return None


def lambda_handler(event, context):
    try:
        image_bytes = base64.b64decode(event["image"])
        result = asyncio.run(analyze_face(image_bytes))

        if result:
            print(result)
            return {"statusCode": 200, "body": json.dumps(result)}
        else:
            return {
                "statusCode": 404,
                "body": json.dumps({"error": "No face detected in the image"}),
            }
    except Exception as e:
        print(f"Error analyzing face: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Error analyzing face: {str(e)}"}),
        }
